<?php $__env->startSection('content'); ?>
  <div class="container portocontainer">
  <div class="row">
    <div class="col-sm">
        <div class="porto_item1 portoblok" data-hover="In this project we had to make a website with login system and several lists. Costumers were able to check products in the list. Company's were able to post products in the list and the admin had to verify company's before they were able to post." onclick="location.href='/portfolio';" style="cursor: pointer;">
            </div>
    </div>
    <div class="col-sm">
      <div class="porto_item2 portoblok" data-hover2="Here I'll show you how and why I've made this website, step by step." onclick="location.href='/portfolio';" style="cursor: pointer;">
       <h1>Portfolio</h1>
          <p>Casperbosma.com</p>
           </div>
    </div>
    <div class="col-sm">
         <div class="porto_item3 portoblok" data-hover3="Room for your project" onclick="location.href='/portfolio';" style="cursor: pointer;">
      
            </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.portfoliolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/portfolio.blade.php ENDPATH**/ ?>