<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.magnific-popup.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/gallery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/scrolleffects.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/scrolleffectsonce.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/hide-nav.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/preloader.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/preloader-waiter.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/onclick-hide.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/layouts/partials/footer-scripts-local.blade.php ENDPATH**/ ?>