<!DOCTYPE html>
<html lang="en">
 <head>
     <link rel="icon" href="/public/images/trees.png" type="image/x-icon"/>
     <link rel="shortcut icon" href="/public/images/trees.png" type="image/x-icon"/>
   <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </head>
 <body id="page-top">
<?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.partials.footer-scripts-local', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </body>
</html><?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/layouts/mainlayout.blade.php ENDPATH**/ ?>