 <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Casper Bosma Copyright &copy; 2019 - 2019. All rights reserved</div>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>