 <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger menutext" href="/">Casper Bosma</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto my-2 my-lg-0">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger menutext" href="/#about">About me</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger menutext" href="/#skills">Skills</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger menutext" href="/#portfolio">Portfolio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger menutext" href="/#contact">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/layout/partials/nav.blade.php ENDPATH**/ ?>