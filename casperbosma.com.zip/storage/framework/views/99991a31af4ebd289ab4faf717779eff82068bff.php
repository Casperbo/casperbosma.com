<?php $__env->startSection('content'); ?>
  <div class="headertest">
      <h1>Casper Bosma</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.portfoliolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\casperbosma.com\resources\views/test.blade.php ENDPATH**/ ?>