@extends('layouts.loginlayout')

@section('content')
<div class="container padding8em">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h2>Dashboard</h2></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <p>You are logged in!</p>
                    
                    <div class="dashboard-buttons" onclick="onclickhide()">
                        <p>Account info</p>
                    </div>
                    <div id="onclickhide" class="account-blok">
                        
         <p>Name: {{ Auth::user()->name }}</p>
           <p>E-mail: {{ Auth::user()->email }}</p>
           <p>Created at: {{ Auth::user()->created_at }}</p>
         <p>Updated at:{{ Auth::user()->updated_at }}</p>
                     <!--
                    <a onclick="onclickhide2()" class="btn-xl btn-light edit-profile-button">Edit profile</a>
                        <div id="onclickhide2" class="edit-profile-blok">
                            
                           {!! Form::open(['url' => 'account/update']) !!}
                            <?php
                            echo Form::text('Name', 'Name');
                            echo Form::text('email', 'E-mail');
                            echo Form::password('password', ['class' => 'awesome']);
                            echo Form::submit('Submit!');
                              ?>
                           {!! Form::close() !!} 
                          
                        </div>
                        
                    </div>
                       <div class="dashboard-buttons" onclick="">
                        <p>Contact form</p>
                    </div>
                    -->
                </div>
            </div>
               <div class="row">
<div class="col-sm-12">
     
    <h2 class="margin-top">reviews</h2>
    
   
    <div class="dashboard-buttons margin-top" onclick="window.location.href='account/create'">New review</div>

    
  <table class="margin-top table table-striped margin-top-1em">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Review</td>
        </tr>
    </thead>
    <tbody>
        @foreach($reviews as $review)
        <tr>
            <td>{{$review->id}}</td>
            <td>{{$review->name}}</td>
            <td>{{$review->reviewtext}}</td>
          <td>
                <a href="{{ route('account.edit',$review->id)}}" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <form action="{{ route('account.destroy', $review->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
  </table>
<div>
</div>
    <div class="col-sm-12">

  @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div>
  @endif
</div>  
        </div>   
    </div>
</div>
@endsection
