<!DOCTYPE html>
<html lang="en">
 <head>
     <link rel="icon" href="/public/images/trees.png" type="image/x-icon"/>
     <link rel="shortcut icon" href="/public/images/trees.png" type="image/x-icon"/>
   @include('layouts.partials.head')
 </head>
 <body id="page-top">
@include('layouts.partials.nav')
@yield('content')
@include('layouts.partials.footer')
@include('layouts.partials.footer-scripts-local')
 </body>
</html>