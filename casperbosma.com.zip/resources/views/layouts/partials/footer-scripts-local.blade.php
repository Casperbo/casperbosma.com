<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="{{ URL::asset('js/jquery.magnific-popup.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/gallery.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/scrolleffects.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/scrolleffectsonce.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/hide-nav.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/preloader.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/preloader-waiter.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/app.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/onclick-hide.js') }}"></script>
