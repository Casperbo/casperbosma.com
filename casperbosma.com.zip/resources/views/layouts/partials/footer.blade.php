 <footer class="bg-light py-5 footerbar">
    <div class="container">
      <div class="small text-center">Casper Bosma Copyright &copy; 2019 - 2019. All rights reserved</div>
    </div>
  </footer>