<script src="public/js/responsivemenu.js"></script>
<script src="public/js/scrolleffects.js"></script>
<script src="public/js/scrolleffectsonce.js"></script>
<script src="public/js/hide-nav.js"></script>
<script src="public/js/preloader.js"></script>
<script src="public/js/preloader-waiter.js"></script>
<script src="public/js/gallery.js"></script>