function onclickhide() {
  var x = document.getElementById("onclickhide");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function onclickhide2() {
  var x = document.getElementById("onclickhide2");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}