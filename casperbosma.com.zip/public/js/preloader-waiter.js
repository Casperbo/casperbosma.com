window.addEventListener('load',function(preloaderwaiter){
  var element5 = document.getElementById("hide");
  element5.classList.add("hide");
  var element = document.getElementById("preload-waiter");
  var element2 = document.getElementById("preload-waiter2");
  var element3 = document.getElementById("preload-waiter3");
  var element4 = document.getElementById("preload-waiter4");
  element.classList.add("typewriter");
  element2.classList.add("typewriter2");
  element3.classList.add("typewriter3");
  element4.classList.add("fadeinheader");
  
});
